BOBO LOGOS + BRAND ASSETS

Official Bobo logo and $Bobo cash-tag artwork.

Official palette:
White       #FFFFFF
Dark Brown  #472C1B
Brown       #6F452D
Bobo Red    #B90B2A
Black       #000000

Do not use these assets to impersonate official Bobo accounts or for deceptive promotion.

